## Goodman Example

Please see the [wiki](https://github.com/snikch/goodman/wiki) for the step by step instructions
