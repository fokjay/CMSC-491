require 'sinatra'

get '/message' do
  "Hello World!"
end
