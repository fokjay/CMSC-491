package amino

// Version
const Version = "0.12.0"
