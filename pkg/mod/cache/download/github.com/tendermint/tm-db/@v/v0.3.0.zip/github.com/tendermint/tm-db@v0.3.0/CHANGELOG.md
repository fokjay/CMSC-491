# Changelog

## 0.3

**2019-11-18**

Special thanks to external contributors on this release:

### BREAKING CHANGES

- [\#26](https://github.com/tendermint/tm-db/pull/26/files) Rename `DBBackendtype` to `BackendType`

## 0.2

**2019-09-19**

Special thanks to external contributors on this release: @stumble

### Features

- [\#12](https://github.com/tendermint/tm-db/pull/12) Add `RocksDB` (@stumble)

## 0.1

**2019-07-16**

Special thanks to external contributors on this release:

### Initial Release

- `db`, `random.go`, `bytes.go` and `os.go` from the tendermint repo.
