# Tendermint DB

Data Base abstractions to be used in applications.
These abstractions are not only meant to be used in applications built on [Tendermint](https://github.com/tendermint/tendermint), but can be used in a variety of applications.
